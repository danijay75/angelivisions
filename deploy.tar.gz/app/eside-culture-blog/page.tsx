import { redirect } from "next/navigation"

export default function LegacyBlogIndexRedirect() {
  redirect("/fr/eside-culture-blog")
}
