import { type NextRequest, NextResponse } from "next/server"
export const dynamic = "force-dynamic"
import { Redis } from "@upstash/redis"
import type { ServiceItem } from "@/data/services"

const redis = new Redis({
  url: process.env.KV_REST_API_URL!,
  token: process.env.KV_REST_API_TOKEN!,
})

const SERVICES_KEY = "av_services_v1"

// Fallback data in case Redis fails
const fallbackServices: ServiceItem[] = [
  {
    id: "captation-video",
    title: "Captation vidéo",
    description: "Système multicaméra professionnel pour l'enregistrement de vos événements en très haute définition.",
    features: ["4K & 8K", "Multicaméra", "Élimination des bruits", "Équipe dédiée"],
    color: "from-blue-500 to-cyan-500",
    image: "/corporate-event-stage.jpg",
  },
  {
    id: "streaming-live",
    title: "Streaming Live",
    description: "Diffusion en direct sur vos plateformes avec régie dynamique intégrée, idéal pour étendre votre audience.",
    features: ["YouTube Live", "Twitch", "Réseaux Sociaux", "Faible latence"],
    color: "from-purple-500 to-pink-500",
    image: "/event-organization.jpg",
  },
  {
    id: "podcast",
    title: "Podcast",
    description: "Création, enregistrement et distribution de podcasts audio et vidéo avec des locaux insonorisés.",
    features: ["Studio professionnel", "Prise de son HD", "Montage experte", "Mixage"],
    color: "from-amber-500 to-orange-500",
    image: "/hip-hop-studio.png",
  },
  {
    id: "booking",
    title: "Booking DJ & Musiciens",
    description: "Trouvez l'artiste parfait pour animer vos événements, soirées privées ou conventions.",
    features: ["DJs internationaux", "Groupes live", "Artistes exclusifs", "Clé en main"],
    color: "from-emerald-500 to-teal-500",
    image: "/music-production-setup.png", 
  },
  {
    id: "vj-video-mapping",
    title: "VJ / Vidéo mapping",
    description: "Création de décors visuels immersifs et d'animations projetées sur mesure pour sublimer l'architecture de vos événements.",
    features: ["Mapping 3D", "VJing en direct", "Scénographie", "Contenus sur mesure"],
    color: "from-fuchsia-500 to-indigo-500",
    image: "/vr-theater-immersive.png",
  },
  {
    id: "label-de-musique",
    title: "Label de musique",
    description: "Production phonographique, développement d'artistes et distribution numérique à l'échelle internationale.",
    features: ["Direction artistique", "Distribution digitale", "Édition musicale", "Promotion"],
    color: "from-rose-500 to-orange-500",
    image: "/abstract-soundscape.png",
  },
]

export async function GET() {
  try {
    console.log("Fetching services from Redis...")

    const servicesData = await redis.get(SERVICES_KEY)
    
    console.log("Redis response type:", typeof servicesData)
    console.log("Redis response preview:", String(servicesData).substring(0, 100))

    let services: ServiceItem[] = fallbackServices

    if (servicesData && typeof servicesData === "string") {
      try {
        // Check if it's valid JSON
        if (servicesData.startsWith("{") || servicesData.startsWith("[")) {
          services = JSON.parse(servicesData)
          console.log("Successfully parsed services from Redis:", services.length, "services")
        } else {
          console.log("Redis returned non-JSON data, using fallback")
        }
      } catch (parseError) {
        console.log("JSON parse error, using fallback:", parseError)
      }
    } else if (servicesData && typeof servicesData === "object") {
      // Redis returned object directly
      services = Array.isArray(servicesData) ? servicesData : fallbackServices
      console.log("Used Redis object data:", services.length, "services")
    } else {
      console.log("No valid data from Redis, initializing with fallback")
      // Initialize Redis with fallback data
      try {
        await redis.set(SERVICES_KEY, JSON.stringify(fallbackServices))
        console.log("Initialized Redis with fallback services")
      } catch (initError) {
        console.log("Failed to initialize Redis:", initError)
      }
    }

    // Ultimate safety filter to ensure 'sport' is NEVER returned
    const filteredServices = services.filter((s: any) => s.id !== "sport")

    return NextResponse.json({ services: filteredServices })
  } catch (error) {
    console.log("Redis operation failed:", error)
    return NextResponse.json({ services: fallbackServices })
  }
}

import { getSessionCookieFromRequest, verifySessionToken } from "@/lib/server/jwt"

export async function POST(request: NextRequest) {
  const sessionToken = getSessionCookieFromRequest(request)
  if (!sessionToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  const session = await verifySessionToken(sessionToken)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  try {
    const { services } = await request.json()

    if (!Array.isArray(services)) {
      return NextResponse.json({ error: "Services must be an array" }, { status: 400 })
    }

    console.log("Saving services to Redis:", services.length, "services")

    try {
      await redis.set(SERVICES_KEY, JSON.stringify(services))
      console.log("Successfully saved services to Redis")
      return NextResponse.json({ success: true })
    } catch (redisError) {
      console.log("Redis save failed:", redisError)
      return NextResponse.json({ error: "Failed to save services" }, { status: 500 })
    }
  } catch (error) {
    console.log("Services POST error:", error)
    return NextResponse.json({ error: "Invalid request" }, { status: 400 })
  }
}
