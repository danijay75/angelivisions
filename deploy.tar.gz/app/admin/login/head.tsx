export default function Head() {
  return <title>Connexion – Admin</title>
}
