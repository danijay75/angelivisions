export default function Head() {
  return <title>Mot de passe oublié – Admin</title>
}
