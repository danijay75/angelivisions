export default function Head() {
  return <title>Réinitialiser le mot de passe – Admin</title>
}
