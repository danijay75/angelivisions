import type { Metadata } from "next"
import { notFound } from "next/navigation"
import type { ServiceItem } from "@/data/services"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, CheckCircle, Phone, Mail } from "lucide-react"

import { Redis } from "@upstash/redis"
import { ArtistsCatalogue } from "@/components/artists-catalogue"

interface ServicePageProps {
  params: Promise<{
    lang: string
    serviceId: string
  }>
}

export const dynamic = "force-dynamic"



const SERVICES_KEY = "av_services_v1"

async function getServices(): Promise<ServiceItem[]> {
  try {
    // Only fetch if env variables are available (prevents build-time crashes if missing)
    if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
      const redis = new Redis({
        url: process.env.KV_REST_API_URL,
        token: process.env.KV_REST_API_TOKEN,
      })
      const servicesData = await redis.get(SERVICES_KEY)

      if (servicesData) {
        if (typeof servicesData === "string") {
          return JSON.parse(servicesData)
        } else if (typeof servicesData === "object" && Array.isArray(servicesData)) {
          return servicesData
        }
      }
    }
  } catch (error) {
    console.log("[v0] Error fetching services directly from Redis:", error)
  }

  // Fallback to default services if API fails
  return [
    {
      id: "captation-video",
      title: "Captation vidéo",
      description: "Système multicaméra professionnel pour l'enregistrement de vos événements en très haute définition.",
      features: ["4K & 8K", "Multicaméra", "Élimination des bruits", "Équipe dédiée"],
      color: "from-blue-500 to-cyan-500",
      image: "/corporate-event-stage.jpg",
    },
    {
      id: "streaming-live",
      title: "Streaming Live",
      description: "Diffusion en direct sur mesure pour événements hybrides, webinaires et concerts avec interactivité en temps réel.",
      features: ["Diffusion Multi-plateformes", "Régie Live", "Habillage Vidéo", "Interactivité"],
      color: "from-teal-500 to-emerald-500",
      image: "/event-organization.jpg",
    },
    {
      id: "podcast",
      title: "Podcast",
      description: "Enregistrement et production de podcasts audio et vidéo pour les entreprises, les marques et les influenceurs.",
      features: ["Studio d'enregistrement", "Post-production", "Diffusion", "Stratégie de contenu"],
      color: "from-violet-500 to-fuchsia-500",
      image: "/abstract-soundscape.png",
    },
    {
      id: "booking-dj-musiciens",
      title: "Booking DJ & Musiciens",
      description: "Programmation musicale sur-mesure pour vos événements avec un catalogue d'artistes exclusifs.",
      features: ["DJ sets", "Musiciens Live", "Direction artistique", "Gestion des contrats"],
      color: "from-fuchsia-500 to-rose-500",
      image: "/live-music-performance.jpg",
    },
    {
      id: "vj-video-mapping",
      title: "VJ / Vidéo mapping",
      description: "Création de décors visuels immersifs et d'animations projetées sur mesure pour sublimer l'architecture de vos événements.",
      features: ["Mapping 3D", "VJing en direct", "Scénographie", "Contenus sur mesure"],
      color: "from-fuchsia-500 to-indigo-500",
      image: "/vr-theater-immersive.png",
    },
    {
      id: "label-de-musique",
      title: "Label de musique",
      description: "Production phonographique, développement d'artistes et distribution numérique à l'échelle internationale.",
      features: ["Direction artistique", "Distribution digitale", "Édition musicale", "Booking DJ & Musiciens"],
      color: "from-rose-500 to-orange-500",
      image: "/abstract-soundscape.png",
    },
  ]
}

export async function generateMetadata({ params }: ServicePageProps): Promise<Metadata> {
  const resolvedParams = await params
  const services = await getServices()
  const service = services.find((s) => s.id === resolvedParams.serviceId)

  if (!service) {
    return {
      title: "Service non trouvé - Angeli Visions",
    }
  }

  return {
    title: `${service.title} - Angeli Visions`,
    description: service.description,
  }
}



export default async function ServicePage({ params }: ServicePageProps) {
  const resolvedParams = await params
  if (!resolvedParams.lang || !["fr", "en"].includes(resolvedParams.lang)) {
    notFound()
  }

  const services = await getServices()
  const service = services.find((s) => s.id === resolvedParams.serviceId)

  if (!service) {
    notFound()
  }


  return (
    <div className="min-h-screen bg-[#0A0A0A] selection:bg-amber-500/30">
      {/* Hero Section (Netflix Cover Style) */}
      <div className="relative h-[60vh] min-h-[500px] w-full flex items-end pb-16">
        {/* Background Image & Overlays */}
        <div className="absolute inset-0 z-0">
          <img
            src={service.image || "/corporate-event-stage.jpg"}
            alt={service.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0A] via-[#0A0A0A]/50 to-transparent" />
        </div>

        {/* Hero Content */}
        <div className="container relative z-10 mx-auto px-4">
          <div className="mb-8">
            <Link href={`/${resolvedParams.lang}/services`}>
              <Button variant="ghost" className="text-white/70 hover:text-white hover:bg-white/10 backdrop-blur-sm -ml-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Retour aux services
              </Button>
            </Link>
          </div>
          <div className="max-w-4xl space-y-4">
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-2">
              <span className="title-gradient">{service.title}</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 leading-relaxed font-light">
              {service.description}
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-2xl font-bold">
                  <span className="title-gradient">Ce que nous proposons</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {service.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                      <span className="text-white">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#121212]/80 border-white/5 backdrop-blur-sm">
              <CardHeader className="border-b border-white/5">
                <CardTitle className="text-2xl font-bold">
                  <span className="title-gradient">Détails du service</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-white/80 space-y-4 font-light leading-relaxed text-lg pt-6">
                <p>Notre équipe d'experts vous accompagne de A à Z dans la réalisation de vos projets.</p>
                <p>Nous combinons créativité, innovation technologique et gestion rigoureuse pour garantir le succès de vos événements et de vos productions.</p>
                <p>N'hésitez pas à nous contacter pour un devis sur mesure ou pour discuter de vos besoins spécifiques.</p>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6 lg:sticky lg:top-24 h-fit">
            <Card className="bg-gradient-to-br from-[#121212] via-[#0A0A0A] to-[#121212] border-amber-500/20 shadow-2xl shadow-amber-500/10 overflow-hidden backdrop-blur-md">
              <CardHeader className="pb-4 border-b border-white/5">
                <CardTitle className="text-white text-2xl font-light">Vous avez un projet ?</CardTitle>
                <div className="text-sm text-amber-500/80">Discutons de vos ambitions</div>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <Link href={`/${resolvedParams.lang}/devis`} className="block">
                  <Button className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 text-lg py-6 rounded-xl shadow-[0_0_20px_rgba(245,158,11,0.2)] transition-all hover:scale-[1.02] font-semibold border border-transparent hover:border-amber-400">
                    Parlons-en !
                  </Button>
                </Link>
                <div className="space-y-4 pt-4 border-t border-white/10">
                  <div className="flex items-center text-white group">
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center mr-3 group-hover:bg-blue-500/20 transition-colors">
                      <Phone className="w-4 h-4 text-blue-400" />
                    </div>
                    <a href="tel:+33663796742" className="hover:text-white transition-colors font-medium">
                      +33 6 63 79 67 42
                    </a>
                  </div>
                  <div className="flex items-center text-white group">
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center mr-3 group-hover:bg-blue-500/20 transition-colors">
                      <Mail className="w-4 h-4 text-blue-400" />
                    </div>
                    <a href="mailto:contact@angelivisions.com" className="hover:text-white transition-colors font-medium">
                      contact@angelivisions.com
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Intégration du Catalogue Artistes pour le Label de Musique */}
      {service.id === "label-de-musique" && (
        <div className="container mx-auto px-4 py-16 border-t border-white/5">
          <ArtistsCatalogue lang={resolvedParams.lang as "fr" | "en" | "es"} />
        </div>
      )}
    </div>
  )
}
