"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import { Partner } from "@/data/partners"
import { useI18n } from "@/components/i18n/i18n-provider"
import { Skeleton } from "@/components/ui/skeleton"

export default function PartnersSection() {
  const { t, lang } = useI18n()
  const [partners, setPartners] = useState<Partner[]>([])
  const [mounted, setMounted] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return

    const fetchPartners = async () => {
      try {
        const res = await fetch("/api/partners")
        if (res.ok) {
          const data = await res.json()
          if (data && data.partners && Array.isArray(data.partners)) {
            setPartners(data.partners)
          }
        }
      } catch (error) {
        console.error("Failed to fetch partners:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPartners()
  }, [mounted])

  if (!mounted || loading) {
    return (
      <section id="partenaires" className="py-8 bg-transparent border-t border-black/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
              {mounted ? t("partners.title") : "Nos partenaires"}
            </h2>
          </div>
          <div className="flex flex-wrap justify-center gap-8 items-center">
             {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-[130px] h-[130px] md:w-[150px] md:h-[150px] rounded-[32px] bg-white/5" />
             ))}
          </div>
        </div>
      </section>
    )
  }

  if (partners.length === 0) return null

  return (
    <section id="partenaires" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-4">

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-amber-500/50" />
            <span className="sunset-gradient bg-clip-text text-transparent text-[11px] uppercase tracking-[0.4em] font-display font-bold">
               Expertises & Réseaux
            </span>
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-amber-500/50" />
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-bold title-gradient">
            {t("partners.title")}
          </h2>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-6 md:gap-10 items-center max-w-6xl mx-auto">
          {partners.map((partner, index) => {
            return (
              <motion.div
                key={partner.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                viewport={{ once: true }}
                className="relative group"
              >
                <div className="w-[120px] h-[120px] md:w-[160px] md:h-[160px] rounded-[2.5rem] bg-white/[0.02] border border-white/5 backdrop-blur-md flex items-center justify-center p-8 transition-all duration-700 group-hover:bg-white/[0.07] group-hover:border-white/20 group-hover:scale-105 shadow-2xl group-hover:shadow-amber-500/10">
                  <Image
                    src={partner.logo}
                    alt={partner.name}
                    width={120}
                    height={120}
                    className="w-full h-full object-contain grayscale brightness-[10] opacity-30 group-hover:grayscale-0 group-hover:brightness-100 group-hover:opacity-100 transition-all duration-700 ease-out"
                  />
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
